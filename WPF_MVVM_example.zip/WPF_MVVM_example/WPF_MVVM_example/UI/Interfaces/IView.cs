﻿namespace WPF_MVVM_example.UI.Interfaces
{
    interface IView
    {
        void ShowMessage(string text);
    }
}
