﻿namespace WPF_MVVM_example.UI.Interfaces
{
    interface ICalculateView : IView
    {
        int Calculate();
    }
}
