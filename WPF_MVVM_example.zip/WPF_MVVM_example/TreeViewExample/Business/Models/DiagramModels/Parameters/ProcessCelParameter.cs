﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeViewExample.Business.Models.DiagramModels.Parameters
{
    public class ProcessCelParameter : Parameter
    {
        #region Fields

        private ProcessCel _Processcel;



        #endregion

        #region Properties

        //public ProcessCel Processcel
        //{
        //    get { return _Processcel; }
        //    set { SetProperty(ref _Processcel, value); }
        //}

        #endregion

        #region Methods



        #endregion
    }
}
