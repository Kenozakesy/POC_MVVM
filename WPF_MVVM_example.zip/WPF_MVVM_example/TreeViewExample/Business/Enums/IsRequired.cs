﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeViewExample.Business.Enums
{
    //moet een oplossing bieden voor de conversie met de database
    public enum IsRequired
    {
        Required,
        Optional,
        NotAvailable
    }

    
}
