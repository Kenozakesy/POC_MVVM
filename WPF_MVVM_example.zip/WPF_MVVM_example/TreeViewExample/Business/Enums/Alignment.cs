﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeViewExample.Business.Enums
{
    public enum Alignment
    {
        Left = 0,
        Right = 1,
        Center = 2
    }
}
