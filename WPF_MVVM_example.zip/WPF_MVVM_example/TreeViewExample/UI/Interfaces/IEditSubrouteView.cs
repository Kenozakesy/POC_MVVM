﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPF_MVVM_example.UI.Interfaces;

namespace TreeViewExample.UI.Interfaces
{
    public interface IEditSubrouteView : IView
    {
    }
}
